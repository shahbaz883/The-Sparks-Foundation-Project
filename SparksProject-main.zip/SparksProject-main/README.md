# SparksProject
I created this project for "The Sparks Foundation" using Frontend which includes HTML, CSS and Bootstrap and for backend i used PHP and MYSQL.
