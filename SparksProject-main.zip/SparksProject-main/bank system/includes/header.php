<nav class="navbar navbar-fixed-top " style="background-color:#34d9eb;">
<div class="container">
<div class="navbar-header">
<button class="navbar-toggle" data-toggle="collapse" data-target="#mynavbar">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<div>
<class="logo">
                <img src= "banklogo.jpg" alt=""
                length=100
                width=102 align=left >            
                              
<a class="navbar-brand" style="color: purple;margin-left:30px;"> <h3> <i><b>  Rhyme Bank</b></i> </h3> </a>
</div>
</div> 
<div class="collapse navbar-collapse" id="mynavbar">
<ul class="nav navbar-nav navbar-right" >
<li>
    <a href = "index.php" style="color: purple;">
    <div> 
        <button class="btn">
            <span class = "glyphicon glyphicon-home">
                <button class="btn">
                    <b>Home</b>
                </button>
            </span>
        </button>
    </div>
</a>
</li>
<li>
    <a href="user.php" style="color: purple;">
    <div> 
        <button class="btn">
            <span class="glyphicon glyphicon-user">
                <button class="btn">
                    <b>New User</b>
                </button>
            </span>
        </button>
    </div>
</a>
</li>
<li>
    <a href="transaction.php" style="color: purple;">
    <div> 
        <button class="btn">
            <span class="glyphicon glyphicon-transfer">
                <button class="btn">
                    <b>Transfer Money</b>
                </button>
            </span>
        </button>
    </div>
</a>
</li>
<li>
    <a href="history.php" style="color:purple;">
    <div> 
        <button class="btn">
            <span class="glyphicon glyphicon-inbox">
                <button class="btn">
                    <b>History</b>
                </button>
            </span>
        </button>
        
    </div>
</a>
</li>
</ul>
</div>
</div>
</nav>
